import 'package:t_server/core/method.dart';
import 'package:t_server/core/routers/route_handler.dart';
import 'package:t_server/core/routers/t_request_handler.dart';

abstract class IRouter {
  void get(String path, TRequestHandler handler);
  void post(String path, TRequestHandler handler);
  void put(String path, TRequestHandler handler);
  void delete(String path, TRequestHandler handler);
  void path(String path, TRequestHandler handler);
  RouteHandler? find(Method method, String path, Map<String, String> outParams);
}
