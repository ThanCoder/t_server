import 'dart:convert';
import 'dart:io';

import 'package:t_server/core/extensions/http_extensions.dart';

class TRequestHandler {
  final HttpRequest raw;
  final Map<String, String> params;

  TRequestHandler(this.raw, this.params);

  Map<String, String> get query => raw.uri.queryParameters;

  Future<String> body() async {
    return await utf8.decoder.bind(raw).join();
  }

  Future<void> sendHtml(String html) {
    return raw.sendHtml(html);
  }
}
