import 'dart:io';

import 'package:t_server/core/routers/t_request_handler.dart';

typedef HttpHandler = void Function(TRequestHandler req);
typedef SocketHandler = void Function(TRequestHandler req, WebSocket socket);

/// --- RouteHandler ---
/// Stores a route template and handler function
class RouteHandler {
  final String template;
  final TRequestHandler handler;
  const RouteHandler(this.template, this.handler);

  /// Match request URL against template
  /// Return path parameters if match, otherwise null
  Map<String, String>? match(String url) {
    final uri = Uri.parse(url);
    final segments = uri.pathSegments;
    final templateSegments = template
        .split('/')
        .where((s) => s.isNotEmpty)
        .toList();

    if (segments.length != templateSegments.length) return null;

    final params = <String, String>{};
    for (var i = 0; i < templateSegments.length; i++) {
      final seg = templateSegments[i];
      if (seg.startsWith(':')) {
        // path param
        final key = seg.substring(1);
        params[key] = segments[i];
      } else if (seg != segments[i]) {
        // literal mismatch
        return null;
      }
    }
    return params;
  }
}
