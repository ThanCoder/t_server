import 'dart:io';

import 'package:t_server/core/index.dart';
import 'package:t_server/core/interfaces/i_router.dart';
import 'package:t_server/core/method.dart';
import 'package:t_server/core/routers/t_request_handler.dart';
import 'package:t_server/core/routers/t_socket_handler.dart';

/// --- TServer ---
/// Main server class
class TServer {
  ///
  /// --- Static ---
  ///
  static TServer? _instance;
  static TServer get getInstance {
    _instance ??= TServer();
    return _instance!;
  }

  IRouter? _router;
  TSocketRouter? _socketRouter;
  HttpServer? _server;
  final serverParams = <String, Map<String, String>>{};

  TServer() {
    serverParams.clear();
  }
  void setRouter(IRouter router) {
    _router = router;
  }

  void setSocketRouter(TSocketRouter socketRouter) {
    _socketRouter = socketRouter;
  }

  String? _host;

  ///
  /// ### Your Start Server [host address]
  ///
  String? get host => _host ?? '';

  ///
  /// ### Server is Running
  ///
  bool get isServerRunning => _server != null;

  ///
  /// ### Your Start Server [PORT]
  ///
  int get port {
    if (_server != null) return _server!.port;
    return -1;
  }

  ///
  /// ### Core HttpServer Class
  ///
  HttpServer? get httpServer => _server;

  ///
  /// ### init Server
  ///
  Future<void> start(
    String host,
    int port, {
    int backlog = 0,
    bool v6Only = false,
    bool shared = false,
    void Function()? onStartServer,
  }) async {
    _host = host;
    _server = await HttpServer.bind(
      host,
      port,
      backlog: backlog,
      v6Only: v6Only,
      shared: shared,
    );
    onStartServer?.call();

    _server!.listen((rawReq) async {
      // WebSocket upgrade check
      if (WebSocketTransformer.isUpgradeRequest(rawReq)) {
        final socket = await WebSocketTransformer.upgrade(rawReq);
        final tReq = TRequestHandler(rawReq, {});
        _socketRouter?.handle(tReq, socket);
        return;
      }
      if (_router == null) {
        rawReq.sendHtml('<h1>Router Not Found!</h1>');
      }

      // HTTP request
      final params = <String, String>{};
      final route = _router?.find(
        Method.fromName(rawReq.method),
        rawReq.uri.path,
        params,
      );

      if (route != null) {
        serverParams[rawReq.uri.path] = params;
        // route.handler(rawReq);
        // route.handler.raw.
      } else {
        rawReq.sendNotFoundHtml();
      }
    });
  }

  Future<void> stop({bool force = false}) async {
    if (!isServerRunning) return;
    await _server?.close(force: force);
    _server = null;
  }
}
